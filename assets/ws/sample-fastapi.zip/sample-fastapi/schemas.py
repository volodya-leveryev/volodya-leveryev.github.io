from typing import Optional

from pydantic import BaseModel


class Auth(BaseModel):
    username: str
    password: str


class StudentBase(BaseModel):
    last_name: str
    first_name: str
    second_name: Optional[str] = ''
    id_number: str


class StudentCreate(StudentBase):
    pass


class Student(StudentBase):
    id: int

    class Config:
        orm_mode = True


class CourseBase(BaseModel):
    code: str
    name: str


class CourseCreate(CourseBase):
    pass


class Course(CourseBase):
    id: int

    class Config:
        orm_mode = True
