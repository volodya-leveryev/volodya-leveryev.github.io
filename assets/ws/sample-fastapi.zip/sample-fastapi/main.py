from typing import Optional
import asyncio
from datetime import datetime, timezone, timedelta

from fastapi import FastAPI, Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
import jwt

import crud
import schemas
from database import SessionLocal

app = FastAPI()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_user(token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, 'secret', algorithms="HS256")
        if payload.get("sub") != "ivanov":
            raise HTTPException(401, detail="Invalid token")
        if payload.get("iss") != "univer":
            raise HTTPException(401, detail="Invalid token")
    except jwt.PyJWTError:
        raise HTTPException(401, detail="Invalid token")
    return "ivanov"


@app.post("/auth/")
async def auth(auth: schemas.Auth):
    if auth.username == 'ivanov' and auth.password == 'Pa$$w0rd':
        period = timedelta(minutes=60)
        skew = timedelta(minutes=5)
        payload = {
            "sub": "ivanov",
            "exp": datetime.now(tz=timezone.utc) + period + skew,
            "nbf": datetime.now(tz=timezone.utc) - skew,
            "iat": datetime.now(tz=timezone.utc),
            "iss": "univer",
        }
        secret = "secret"
        token = jwt.encode(payload, secret, algorithm="HS256")
        return {"token": token}
    raise HTTPException(status_code=401, detail="Invalid username or password")



@app.get("/students/", response_model=list[schemas.Student])
async def read_students(user: str = Depends(get_user), skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    return crud.get_students(db=db, skip=skip, limit=limit)


@app.post("/students/", response_model=schemas.Student)
async def create_student(student: schemas.StudentCreate, db: Session = Depends(get_db)):
    return crud.create_student(db=db, student=student)


@app.post("/courses/", response_model=schemas.Course)
async def create_student(course: schemas.CourseCreate, db: Session = Depends(get_db)):
    return crud.create_course(db=db, course=course)
