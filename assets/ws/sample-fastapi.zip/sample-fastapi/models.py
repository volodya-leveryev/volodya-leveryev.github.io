from sqlalchemy import Integer, Column, String

from database import Base


class Student(Base):
    __tablename__ = 'student'
    id = Column(Integer, primary_key=True)
    last_name = Column(String(50), nullable=False)
    first_name = Column(String(50), nullable=False)
    second_name = Column(String(50))
    id_number = Column(String(20), nullable=False)


class Course(Base):
    __tablename__ = 'course'
    id = Column(Integer, primary_key=True)
    code = Column(String(30), nullable=False)
    name = Column(String(50), nullable=False)
