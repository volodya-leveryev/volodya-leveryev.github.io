from sqlalchemy.orm import Session

import models
import schemas


def get_students(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.Student).offset(skip).limit(limit).all()


def get_student(db: Session, obj_id: int):
    return db.query(models.Student).filter(models.Student.id == obj_id).first()


def create_student(db: Session, student: schemas.StudentCreate):
    db_student = models.Student()
    db_student.last_name = student.last_name
    db_student.first_name = student.first_name
    db_student.second_name = student.second_name
    db_student.id_number = student.id_number
    db.add(db_student)
    db.commit()
    db.refresh(db_student)
    return db_student


def get_courses(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.Course).offset(skip).limit(limit).all()


def get_course(db: Session, obj_id: int):
    return db.query(models.Course).filter(models.Course.id == obj_id).first()


def create_course(db: Session, course: schemas.CourseCreate):
    db_course = models.Student()
    db_course.name = course.name
    db_course.code = course.code
    db.add(db_course)
    db.commit()
    db.refresh(db_course)
    return db_course
