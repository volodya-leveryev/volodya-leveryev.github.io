# FastAPI example

Миграция базы данных

```
alembic revision --autogenerate
alembic upgrade <ID ревизии>
```

Для запуска приложения

```
uvicorn main:app --reload
```
