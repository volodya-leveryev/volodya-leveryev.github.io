from django.contrib import admin
from students.models import Student


admin.site.register(Student)
